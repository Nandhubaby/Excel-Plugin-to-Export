package org.joget.excelDatalist;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joget.apps.app.service.AppUtil;
import org.joget.apps.datalist.model.DataList;
import org.joget.apps.datalist.model.DataListActionDefault;
import org.joget.apps.datalist.model.DataListActionResult;
import org.joget.apps.form.service.FileUtil;
import org.joget.commons.util.LogUtil;
import org.joget.workflow.util.WorkflowUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.*;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


import org.joget.apps.datalist.service.DataListService;
import org.joget.apps.datalist.model.DataListCollection;

public class ExcelDatalist extends DataListActionDefault {
    String recordId = "73ffb231-ea65-4382-ae9f-55bc56690215";
    String imgTable = "logo";
    String imgName = "CTG.png";
    String listNames = getPropertyString("listIdentifier");
    private final static String MESSAGE_PATH = "messages/DownloadPdfDatalistAction";
    String data="";

    @Override
    public String getName() {
        return "Excel Export Action";
    }

    @Override
    public String getVersion() {
        return "7.0.2";
    }

    @Override
    public String getClassName() {
        return getClass().getName();
    }

    @Override
    public String getLabel() {
        return "Excel download";
    }

    @Override
    public String getDescription() {
        return "Excel Datalist";
    }
    @Override
    public String getPropertyOptions() {
        return AppUtil.readPluginResource(getClassName(), "/properties/ExportExcel.json", null, true, MESSAGE_PATH);
    }

    @Override
    public String getLinkLabel() {
        return getPropertyString("label");
    }

    @Override
    public String getHref() {
        return getPropertyString("href");
    }

    @Override
    public String getTarget() {
        return "post";
    }

    @Override
    public String getHrefParam() {
        return getPropertyString("hrefParam");
    }

    @Override
    public String getHrefColumn() {
        String recordIdColumn = getPropertyString("recordIdColumn"); //get column id from configured properties options
        if ("id".equalsIgnoreCase(recordIdColumn) || recordIdColumn.isEmpty()) {
            return getPropertyString("hrefColumn"); //Let system to set the primary key column of the binder
        } else {
            return recordIdColumn;
        }
    }

    @Override
    public String getConfirmation() {
        return getPropertyString("confirmation");
    }



    public DataListActionResult executeAction(DataList dataList, String[] rowKeys) {
        String columnVal = getPropertyString("columnNames");
        ArrayList<ArrayList<String>> allRowValues = new ArrayList<>();
        DataListCollection rows = dataList.getRows();
        ArrayList datalistAllRowIds = new ArrayList();

        DataListService dataListService = (DataListService) AppUtil.getApplicationContext().getBean("dataListService");
        for(int index =0 ; index <rows.size(); index++) {
            String rowId = dataListService.evaluateColumnValueFromRow(rows.get(index), "id").toString();
            datalistAllRowIds.add(rowId);

        }
        HttpServletRequest request = WorkflowUtil.getHttpServletRequest();
        HttpServletResponse response = WorkflowUtil.getHttpServletResponse();
        if (request != null && !"POST".equalsIgnoreCase(request.getMethod())) {
            return null;
        }
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = getConnection();
            String selectedId = "";
            for (int i = 0; i < rowKeys.length; i++) {
                String id = rowKeys[i];
                selectedId += "'" + id + "'";
                if (i < rowKeys.length - 1) {
                    selectedId += ",";
                }
                LogUtil.info("selected idd", selectedId);
                String[] colIdValues = columnVal.split(",");
                ArrayList<String> rowValue = new ArrayList<>();
                for (int j = 0; j < colIdValues.length; j++) {
                    int indexOfIdValue = datalistAllRowIds.indexOf(id);
                    String columnData = colIdValues[j];
                    data = dataListService.evaluateColumnValueFromRow(rows.get(indexOfIdValue), columnData).toString();
                    rowValue.add(data);
                }
                allRowValues.add(rowValue);
            }
            //createNewFile(request, response, con, columnVal,allRowValues);
            writeToExistingFile(request,response,allRowValues);
        } catch (Exception e) {
            LogUtil.error(getClassName(), e, "");
        } finally {
            closeConnection(rs, pstmt, con);
        }
        return prepareResult(null, null);
    }
    public void createNewFile(HttpServletRequest request, HttpServletResponse response,Connection con,String label, ArrayList<ArrayList<String>> allRowValues) throws ServletException, IOException {
        int rowIndex = 0;
        File profileImage = FileUtil.getFile(imgName, imgTable, recordId);
        byte [] bytes = Files.readAllBytes(profileImage.toPath());
        String imgb64 = Base64.getEncoder().encodeToString(bytes);
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sample Sheet");
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String curDate = dateFormat.format(new Date());
        String html = listNames;

        Row row = sheet.createRow(0);
        Cell cell = row.createCell(2);
        cell.setCellValue(html);
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        cell.setCellStyle(cellStyle);

        row.setHeightInPoints(80);
        sheet.setColumnWidth(0, 8000);
        XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
        XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, 0, 0, 1,  1);

        byte[] imageBytes = Base64.getDecoder().decode(imgb64);
        int pictureIndex = workbook.addPicture(imageBytes, Workbook.PICTURE_TYPE_PNG);
        drawing.createPicture(anchor, pictureIndex);

        try {
            rowIndex = 2; //rowindex to print the values
            Row headerRow = sheet.createRow(rowIndex++);
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            String[] labelName = label.split(",");
            LogUtil.info("label names--->", Arrays.toString(labelName));
            for (int i = 0; i < labelName.length; i++) {
                Cell headerCell = headerRow.createCell(i);
                headerCell.setCellValue(labelName[i]);
                headerCell.setCellStyle(headerStyle);
            }
            for (ArrayList<String> rowValue : allRowValues) {
                Row dataRow = sheet.createRow(rowIndex++);
                LogUtil.info(String.valueOf(rowValue), "row value array");
                for (int i = 0; i < rowValue.size(); i++) {
                    Cell dataCell = dataRow.createCell(i);
                    dataCell.setCellValue(rowValue.get(i));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        String filename = listNames + ".xlsx";
        writeResponse(request, response, outputStream.toByteArray(), filename, "application/octet-stream");
        writeToExistingFile(request,response,allRowValues);
    }

    public void writeToExistingFile(HttpServletRequest request, HttpServletResponse response, ArrayList<ArrayList<String>> allRowValues) throws ServletException, IOException {
        String filePath = getPropertyString("filePath");
        String rows = getPropertyString("rowFilter");
        String workingSheet = getPropertyString("workbookSheet");
        int rowsToSkip = Integer.parseInt(rows);
        int sheetIndex = Integer.parseInt(workingSheet);
        LogUtil.info(String.valueOf(sheetIndex),"sheet index");
        FileInputStream fileInputStream = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fileInputStream);
        Sheet sheet = workbook.getSheetAt(sheetIndex);
        LogUtil.info(String.valueOf(workbook.getActiveSheetIndex()),"Active sheet before");
        //  Sheet sheet = workbook.getSheetAt(0); // Assuming you want to work with the first sheet
        sheet.setSelected(true);
        workbook.setActiveSheet(sheetIndex);
        for (int i = 0; i <= rowsToSkip; i++) {
            //  sheet.removeRow(sheet.getRow(i));
            sheet.getRow(i);
        }
        LogUtil.info(String.valueOf(workbook.getActiveSheetIndex()),"Active sheet after");
        int newRowNumber = sheet.getLastRowNum() + 1;
        for (ArrayList<String> rowValue : allRowValues) {
            Row newRow = sheet.createRow(newRowNumber++);
            int cellIndex = 0;
            for (String cellData : rowValue) {
                Cell cell = newRow.createCell(cellIndex++);
                cell.setCellValue(cellData);
            }
        }

        // Write the workbook to a ByteArrayOutputStream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        String filename = listNames + ".xlsx";
        writeResponse(request, response, outputStream.toByteArray(), filename, "application/octet-stream");
    }

    protected void writeResponse(HttpServletRequest request, HttpServletResponse response, byte[] bytes, String filename, String contentType) throws IOException, ServletException {
        OutputStream out = response.getOutputStream();
        try {
            String name = URLEncoder.encode(filename, "UTF8").replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=" + name + "; filename*=UTF-8''" + name);
            response.setContentType(contentType + "; charset=UTF-8");
          //  response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=UTF-8");
            if (bytes.length > 0) {
                response.setContentLength(bytes.length);
                out.write(bytes);
            }
        } finally {
            out.flush();
            out.close();
            request.getRequestDispatcher(filename);
            //          request.getRequestDispatcher(filename).forward(request, response);
        }
    }
    public Connection getConnection() {
        Connection con = null;
        DataSource ds = (DataSource) AppUtil.getApplicationContext().getBean("setupDataSource");
        try {
            con = ds.getConnection();
        } catch (SQLException ex) {
        }
        return con;
    }
    public void closeConnection(ResultSet rs, PreparedStatement pstmt, Connection con) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }

    }
    private DataListActionResult prepareResult(String url, String errorMessage) {
        if (url != null && !url.isEmpty()) {
            DataListActionResult result = new DataListActionResult();
            result.setType(DataListActionResult.TYPE_REDIRECT);
            if (errorMessage != null) {
                result.setMessage(errorMessage);
            }
            result.setUrl(url);
            return result;
        }
        return null;
    }


}



