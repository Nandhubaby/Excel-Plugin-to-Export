package org.joget.excelplugin;

import java.io.*;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.joget.apps.app.service.AppUtil;
import org.joget.apps.datalist.model.DataList;
import org.joget.apps.datalist.model.DataListActionDefault;
import org.joget.apps.datalist.model.DataListActionResult;
import org.joget.apps.form.service.FileUtil;
import org.joget.commons.util.LogUtil;
import org.joget.workflow.util.WorkflowUtil;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Base64;
import java.util.ArrayList;
import java.util.Date;
import java.io.File;



public class exportExcel extends DataListActionDefault {
    String recordId = "73ffb231-ea65-4382-ae9f-55bc56690215";
    String imgTable = "logo";
    String imgName = "CTG.png";
    private final static String MESSAGE_PATH = "messages/DownloadPdfDatalistAction";
   private List<String> getColValues = new ArrayList<>();

    @Override
    public String getName() {
        return "Excel Export Action";
    }

    @Override
    public String getVersion() {
        return "7.0.2";
    }

    @Override
    public String getClassName() {
        return getClass().getName();
    }

    @Override
    public String getLabel() {
        //support i18n
        return "Excel Export";
    }

    @Override
    public String getDescription() {
        return "Excel Export";
    }
    @Override
    public String getPropertyOptions() {
        return AppUtil.readPluginResource(getClassName(), "/properties/ExportExcel.json", null, true, MESSAGE_PATH);
    }

    @Override
    public String getLinkLabel() {
        return getPropertyString("label");
    }

    @Override
    public String getHref() {
        return getPropertyString("href");
    }

    @Override
    public String getTarget() {
        return "post";
    }

    @Override
    public String getHrefParam() {
        return getPropertyString("hrefParam");
    }

    @Override
    public String getHrefColumn() {
        String recordIdColumn = getPropertyString("recordIdColumn"); //get column id from configured properties options
        if ("id".equalsIgnoreCase(recordIdColumn) || recordIdColumn.isEmpty()) {
            return getPropertyString("hrefColumn"); //Let system to set the primary key column of the binder
        } else {
            return recordIdColumn;
        }
    }

    @Override
    public String getConfirmation() {
        return getPropertyString("confirmation");
    }


    @Override
    public DataListActionResult executeAction(DataList dataList, String[] rowKeys) {
        String tableNames = getPropertyString("tablename");
        String columnVal = getPropertyString("columnId");
        String listNames = getPropertyString("listname");
        String label = getPropertyString("columnlabel");
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        HttpServletRequest request = WorkflowUtil.getHttpServletRequest();
        HttpServletResponse response = WorkflowUtil.getHttpServletResponse();
        if (request != null && !"POST".equalsIgnoreCase(request.getMethod())) {
            return null;
        }
        try {
            con = getConnection();
            createNewFile(request,response,con,tableNames,columnVal,label);
        }
        catch (Exception e) {
            LogUtil.error(getClassName(), e, "");
        } finally {
            closeConnection(rs, pstmt, con);
        }
        return prepareResult(null, null);
    }
    public void createNewFile(HttpServletRequest request, HttpServletResponse response,Connection con, String tableNames,String columnVal,String label) throws ServletException, IOException {
        int rowIndex = 0;
        String listNames = getPropertyString("listname");
        File profileImage = FileUtil.getFile(imgName, imgTable, recordId);
        byte [] bytes = Files.readAllBytes(profileImage.toPath());
        String imgb64 = Base64.getEncoder().encodeToString(bytes);


        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sample Sheet");
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String curDate = dateFormat.format(new Date());
        String html = listNames;

        Row row = sheet.createRow(0);
        Cell cell = row.createCell(2);
        cell.setCellValue(html);
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        cell.setCellStyle(cellStyle);

        row.setHeightInPoints(80);
        sheet.setColumnWidth(0, 8000);
     //  sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, sheet.getLastRowNum()));
        XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
        XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, 0, 0, 1,  1);

        byte[] imageBytes = Base64.getDecoder().decode(imgb64);
        int pictureIndex = workbook.addPicture(imageBytes, Workbook.PICTURE_TYPE_PNG);
        drawing.createPicture(anchor, pictureIndex);
        LogUtil.info(String.valueOf(row.getLastCellNum()),"last cell num");
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            if (!con.isClosed()) {
                String query = "select " + columnVal + " from app_fd_" + tableNames;
                LogUtil.info("Query-->", query);
                pstmt = con.prepareStatement(query);
                rs = pstmt.executeQuery();
                rowIndex = 3;
                Row headerRow = sheet.createRow(rowIndex++);
                String[] colLabel = label.split(",");
                CellStyle headerStyle = workbook.createCellStyle();
                Font headerFont = workbook.createFont();
                headerFont.setBold(true);
                headerStyle.setFont(headerFont);
                headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
                headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                for (int j = 0; j < colLabel.length; j++) {
                    String labelName = colLabel[j];
                    Cell headerCell = headerRow.createCell(j);
                    headerCell.setCellValue(labelName);
                    headerCell.setCellStyle(headerStyle);
                }
                String[] colArray = columnVal.split(",");
                while (rs.next()) {
                    Row rows = sheet.createRow(rowIndex++);
                    for (int a = 0; a < colArray.length; a++) {
                        String columns = colArray[a];
                        String getCol = rs.getString(columns);
                        Cell cells = rows.createCell(a);
                        cells.setCellValue(getCol);
                    }
                }
            }
        }
        catch (SQLException e) {
            LogUtil.error(getClassName(), e, "");
        } finally {
            closeConnection(rs, pstmt, null);
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        String filename = listNames + curDate + ".xlsx";
        writeResponse(request, response, outputStream.toByteArray(), filename, "application/octet-stream");
        writeToExistingFile(request,response);
    }
    public void writeToExistingFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String filePath = getPropertyString("filePath");
        String rows = getPropertyString("getRows");
        int rowsToSkip = Integer.parseInt(rows);

        // Create a new Excel workbook and sheet
        FileInputStream fileInputStream = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fileInputStream);

        Sheet sheet = workbook.getSheetAt(0); // Assuming you want to work with the first sheet
        for (int i = 3; i <=rowsToSkip; i++) {
            if (sheet.getRow(i) != null) {
                sheet.removeRow(sheet.getRow(i));
            }
        }
      // sheet.shiftRows(rowsToSkip, sheet.getLastRowNum(), -rowsToSkip);

    //     Create a new row and cells to add content
        int newRowNumber = sheet.getLastRowNum() + 1;
        Row newRow = sheet.createRow(newRowNumber);

        Cell cell1 = newRow.createCell(0);
        cell1.setCellValue("New Data 1");

        Cell cell2 = newRow.createCell(1);
        cell2.setCellValue("New Data 2");

        // Write the workbook to a ByteArrayOutputStream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);

        writeResponse(request, response, outputStream.toByteArray(), "Excel.xlsx", "application/octet-stream");

    }
    protected void writeResponse(HttpServletRequest request, HttpServletResponse response, byte[] bytes, String filename, String contentType) throws IOException, ServletException {
        OutputStream out = response.getOutputStream();
        try {
            String name = URLEncoder.encode(filename, "UTF8").replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=" + name + "; filename*=UTF-8''" + name);
            response.setContentType(contentType + "; charset=UTF-8");
            if (bytes.length > 0) {
                response.setContentLength(bytes.length);
                out.write(bytes);
            }
        } finally {
            out.flush();
            out.close();
            request.getRequestDispatcher(filename);
//          request.getRequestDispatcher(filename).forward(request, response);
        }
    }
    public Connection getConnection() {
        Connection con = null;
        DataSource ds = (DataSource) AppUtil.getApplicationContext().getBean("setupDataSource");
        try {
            con = ds.getConnection();
        } catch (SQLException ex) {
        }
        return con;
    }
    public void closeConnection(ResultSet rs, PreparedStatement pstmt, Connection con) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }

    }
    private DataListActionResult prepareResult(String url, String errorMessage) {
        if (url != null && !url.isEmpty()) {
            DataListActionResult result = new DataListActionResult();
            result.setType(DataListActionResult.TYPE_REDIRECT);
            if (errorMessage != null) {
                result.setMessage(errorMessage);
            }
            result.setUrl(url);
            return result;
        }
        return null;
    }


}



