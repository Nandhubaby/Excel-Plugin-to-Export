package org.joget.excelplugin;

import java.util.ArrayList;
import java.util.Collection;

import org.joget.commons.util.LogUtil;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

    protected Collection<ServiceRegistration> registrationList;

    public void start(BundleContext context) {
        registrationList = new ArrayList<ServiceRegistration>();
        LogUtil.info("Plugin registered....","");

        //Register plugin here
        registrationList.add(context.registerService(exportExcel.class.getName(), new exportExcel(), null));
        LogUtil.info("plugin installed","");
    }

    public void stop(BundleContext context) {
        for (ServiceRegistration registration : registrationList) {
            registration.unregister();
        }
    }
}